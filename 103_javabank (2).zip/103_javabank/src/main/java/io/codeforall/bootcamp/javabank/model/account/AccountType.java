package io.codeforall.bootcamp.javabank.model.account;

public enum AccountType {

    CHECKING,
    SAVINGS

}

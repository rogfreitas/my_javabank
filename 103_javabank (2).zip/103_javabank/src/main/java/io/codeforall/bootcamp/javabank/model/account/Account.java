package io.codeforall.bootcamp.javabank.model.account;

import io.codeforall.bootcamp.javabank.model.Customer;
import io.codeforall.bootcamp.javabank.model.Model;

/**
 * Common interface for bank accounts, provides methods to access account
 * information and perform account transactions
 */
public interface Account extends Model {

    /**
     * Gets the account balance
     *
     * @return the account balance
     */
    double getBalance();

    /**
     * Gets the account type
     *
     * @return the account type
     */
    AccountType getAccountType();

    /**
     * Credits the account
     *
     * @param amount the amount to credit
     * @see Account#canCredit(double)
     */
    void credit(double amount);

    /**
     * Debits the account
     *
     * @param amount the amount to debit
     * @see Account#canDebit(double)
     */
    void debit(double amount);

    /**
     * Checks if a specific amount can be credited on the account
     *
     * @param amount the amount to check
     * @return {@code true} if the account can be credited
     */
    boolean canCredit(double amount);

    /**
     * Checks if a specific amount can be debited from the account
     *
     * @param amount the amount to check
     * @return {@code true} if the account can be debited
     */
    boolean canDebit(double amount);

    /**
     * Checks if the account can be withdrawn
     *
     * @return {@code true} if withdraw can be done
     */
    boolean canWithdraw();

    /**
     * Returns the owning customer
     *
     * @return the owning customer
     */
    Customer getCustomer();

    /**
     * Sets the owning customer
     *
     * @param customer the owner customer
     */
    void setCustomer(Customer customer);
}
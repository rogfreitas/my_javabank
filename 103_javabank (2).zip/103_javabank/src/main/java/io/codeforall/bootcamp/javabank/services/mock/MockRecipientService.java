package io.codeforall.bootcamp.javabank.services.mock;

import io.codeforall.bootcamp.javabank.model.Recipient;

public class MockRecipientService extends AbstractMockService<Recipient> {
}

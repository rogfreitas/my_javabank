package io.codeforall.bootcamp.javabank.model;

public interface Model {

    Integer getId();

    void setId(Integer id);

}

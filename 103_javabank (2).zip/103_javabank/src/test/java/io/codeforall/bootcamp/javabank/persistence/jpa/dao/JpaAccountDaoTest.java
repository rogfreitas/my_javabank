package io.codeforall.bootcamp.javabank.persistence.jpa.dao;

import io.codeforall.bootcamp.javabank.model.account.AbstractAccount;
import io.codeforall.bootcamp.javabank.model.account.CheckingAccount;
import io.codeforall.bootcamp.javabank.model.account.SavingsAccount;
import io.codeforall.bootcamp.javabank.persistence.TransactionException;
import io.codeforall.bootcamp.javabank.persistence.dao.jpa.JpaAccountDao;
import io.codeforall.bootcamp.javabank.persistence.jpa.JpaSessionManager;
import org.hibernate.HibernateException;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class JpaAccountDaoTest {

    private JpaSessionManager sm;
    private JpaAccountDao customerDao;
    private EntityManager em;

    @Before
    public void setup() {

        sm = mock(JpaSessionManager.class);
        em = mock(EntityManager.class);
        customerDao = new JpaAccountDao(sm);

        when(sm.getCurrentSession()).thenReturn(em);

    }

    @Test
    public void testFindAll() {

        // setup
        List<AbstractAccount> mockAccounts = new ArrayList<>();
        CriteriaQuery criteriaQuery = mock(CriteriaQuery.class);
        CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
        TypedQuery typedQuery = mock(TypedQuery.class);
        when(em.getCriteriaBuilder()).thenReturn(criteriaBuilder);
        when(criteriaBuilder.createQuery(AbstractAccount.class)).thenReturn(criteriaQuery);
        when(em.createQuery(criteriaQuery)).thenReturn(typedQuery);
        when(em.createQuery(anyString(), any(Class.class))).thenReturn(typedQuery);
        when(typedQuery.getResultList()).thenReturn(mockAccounts);

        // exercise
        List<AbstractAccount> customers = customerDao.findAll();

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(typedQuery, times(1)).getResultList();
        assertEquals(mockAccounts, customers);
    }

    @Test(expected = TransactionException.class)
    public void testFindAllFail() {

        // setup
        List<AbstractAccount> mockAccounts = new ArrayList<>();
        CriteriaQuery criteriaQuery = mock(CriteriaQuery.class);
        CriteriaBuilder criteriaBuilder = mock(CriteriaBuilder.class);
        TypedQuery typedQuery = mock(TypedQuery.class);
        when(em.getCriteriaBuilder()).thenReturn(criteriaBuilder);
        when(criteriaBuilder.createQuery(AbstractAccount.class)).thenReturn(criteriaQuery);
        when(em.createQuery(criteriaQuery)).thenReturn(typedQuery);
        when(em.createQuery(anyString(), any(Class.class))).thenReturn(typedQuery);
        when(em.createQuery(any(CriteriaQuery.class))).thenReturn(typedQuery);
        when(typedQuery.getResultList()).thenReturn(mockAccounts);
        doThrow(new HibernateException(new RuntimeException())).when(typedQuery).getResultList();

        // exercise
        customerDao.findAll();

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(typedQuery.getResultList(), times(1));

    }

    @Test
    public void testFindByIdChecking() {

        // setup
        int fakeId = 9999;
        AbstractAccount fakeAccount = new CheckingAccount();
        fakeAccount.setId(fakeId);
        when(em.find(AbstractAccount.class, fakeId)).thenReturn(fakeAccount);

        // exercise
        AbstractAccount customer = customerDao.findById(fakeId);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).find(AbstractAccount.class, fakeId);
        assertEquals(fakeAccount, customer);

    }

    @Test
    public void testFindByIdSavings() {

        // setup
        int fakeId = 9999;
        AbstractAccount fakeAccount = new SavingsAccount();
        fakeAccount.setId(fakeId);
        when(em.find(AbstractAccount.class, fakeId)).thenReturn(fakeAccount);

        // exercise
        AbstractAccount customer = customerDao.findById(fakeId);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).find(AbstractAccount.class, fakeId);
        assertEquals(fakeAccount, customer);

    }

    @Test(expected = TransactionException.class)
    public void testFindByIdFails() {

        // setup
        int fakeId = 9999;
        doThrow(new HibernateException(new RuntimeException())).when(em).find(eq(AbstractAccount.class), anyInt());

        // exercise
        customerDao.findById(fakeId);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).find(AbstractAccount.class, fakeId);

    }

    @Test
    public void testSaveOrUpdateChecking() {

        // setup
        AbstractAccount fakeAccount = new CheckingAccount();
        when(em.merge(any(AbstractAccount.class))).thenReturn(fakeAccount);

        // exercise
        AbstractAccount customer = customerDao.saveOrUpdate(fakeAccount);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).merge(any(AbstractAccount.class));
        assertEquals(fakeAccount, customer);

    }

    @Test
    public void testSaveOrUpdateSavings() {

        // setup
        AbstractAccount fakeAccount = new SavingsAccount();
        when(em.merge(any(AbstractAccount.class))).thenReturn(fakeAccount);

        // exercise
        AbstractAccount customer = customerDao.saveOrUpdate(fakeAccount);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).merge(any(AbstractAccount.class));
        assertEquals(fakeAccount, customer);

    }

    @Test(expected = TransactionException.class)
    public void testSaveOrUpdateFail() {

        // setup
        AbstractAccount fakeAccount = new CheckingAccount();
        doThrow(new HibernateException(new RuntimeException())).when(em).merge(any(AbstractAccount.class));

        // exercise
        customerDao.saveOrUpdate(fakeAccount);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).merge(any(AbstractAccount.class));
    }

    @Test
    public void testDeleteChecking() {

        // setup
        int fakeId = 9999;
        AbstractAccount fakeAccount = new CheckingAccount();
        fakeAccount.setId(fakeId);
        when(em.find(AbstractAccount.class, fakeId)).thenReturn(fakeAccount);

        // exercise
        customerDao.delete(fakeId);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).remove(fakeAccount);

    }

    @Test
    public void testDeleteSavings() {

        // setup
        int fakeId = 9999;
        AbstractAccount fakeAccount = new SavingsAccount();
        fakeAccount.setId(fakeId);
        when(em.find(AbstractAccount.class, fakeId)).thenReturn(fakeAccount);

        // exercise
        customerDao.delete(fakeId);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).remove(fakeAccount);

    }

    @Test(expected = TransactionException.class)
    public void testDeleteFail() {

        // setup
        int fakeId = 9999;
        doThrow(new HibernateException(new RuntimeException())).when(em).find(eq(AbstractAccount.class), anyInt());

        // exercise
        customerDao.delete(fakeId);

        // verify
        verify(sm, times(1)).getCurrentSession();
        verify(sm, never()).stopSession();
        verify(sm, never()).startSession();
        verify(em, times(1)).remove(any(AbstractAccount.class));


    }
}
